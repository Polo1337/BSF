<main class=" main flex flex-row max-w-screen-lg mx-auto ">

<section class="flex  flex-wrap news w-3/4  " style=" justify-content: center;">
    <article id="featured" class="text-center  ">
        <a href="article.php"><img class="flex" src="img/guerre.jpg" alt="" /></a>
        <div class="momo ">
            <h1>La Guerre a changer ! </h1>
        </div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut tempor, tortor at vulputate blandit, magna risus posuere turpis, nec cursus ipsum arcu nec felis. Mauris sed lectus dui. Suspendisse enim elit, tempor ac ullamcorper et, eleifend quis sem. Sed euismod sagittis ligula, a imperdiet sapien molestie nec. Curabitur ut eros a justo fermentum vulputate ac sit amet metus.</p>
        <a href="article.php" class="readmore">Read more</a>
    </article>

     <article id="featured" class="text-center  ">
        <a href="article.php"><img class="flex" src="img/dark.jpg" alt="" /></a>
        <div class="momo ">
            <h1>Un barbecue Dark vador , pour révéler le coté obscur des grillades </h1>
        </div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut tempor, tortor at vulputate blandit, magna risus posuere turpis, nec cursus ipsum arcu nec felis. Mauris sed lectus dui. Suspendisse enim elit, tempor ac ullamcorper et, eleifend quis sem. Sed euismod sagittis ligula, a imperdiet sapien molestie nec. Curabitur ut eros a justo fermentum vulputate ac sit amet metus.</p>
        <a href="article.php" class="readmore">Read more</a>
    </article>
    
    <article class=" text-center">
        <a href="#"><img src="img/cul.jpg" alt="" /></a>
        <div class="momo">
            <h1>Top 10 des mots classes pour parler de cul, pour être salace mais chic</h1>
        </div>
        <p> Aenean quis dignissim diam. Etiam venenatis congue velit, varius gravida mi volutpat ac. Sed ut pretium dolor. Etiam tempor felis ac eros dictum quis consectetur dolor tristique. Aliquam scelerisque, odio vel luctus commodo, nisl nisl vehicula metus, ut lobortis eros sem blandit est.</p>
        <a href="#" class="readmore">Read more</a>
    </article>
    <article class="rightcl  text-center" > 
        <a href="#"><img src="img/insulte.jpg" alt="" /></a>
        <div class="momo">
            <h1>Top 15 des pires insultes, celles qui font très mal à ton amour propre</h1>
        </div>
        <p>1. "Je vais t'enculer tellement fort, que celui qui arrivera à enlever ma bite de ton cul, on l'appellera le Roi Arthur !"<br>
            2. "Vieille trousse à bites" <br>
            ...etc </p>
            <a href="#" class="readmore">Read more</a>
        </article>
        <article id="featured" class=" text-center">
            <a href="#"><img src="img/enfant.jpg" alt="" /></a>
            <div class="momo">
                <h1>Top 10 des dessins d’enfants les plus foirés de l’Histoire, enfin quand on comprend rien à l’Art</h1>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut tempor, tortor at vulputate blandit, magna risus posuere turpis, nec cursus ipsum arcu nec felis. Mauris sed lectus dui. Suspendisse enim elit, tempor ac ullamcorper et, eleifend quis sem. Sed euismod sagittis ligula, a imperdiet sapien molestie nec. Curabitur ut eros a justo fermentum vulputate ac sit amet metus.</p>
            <a href="#" class="readmore">Read more</a>
        </article>
        <article class=" text-center">
            <a href="#"><img src="img/rare.jpg" alt="" /></a>
            <div class="momo">
                <h1>Top 15 des trucs qui étaient considérés comme normaux autrefois, mais qui sont très très chelous</h1>
            </div>
            <p> Aenean quis dignissim diam. Etiam venenatis congue velit, varius gravida mi volutpat ac. Sed ut pretium dolor. Etiam tempor felis ac eros dictum quis consectetur dolor tristique. Aliquam scelerisque, odio vel luctus commodo, nisl nisl vehicula metus, ut lobortis eros sem blandit est.</p>
            <a href="#" class="readmore">Read more</a>
        </article>
        <article class="rightcl text-center">
            <a href="#"><img src="img/monopoly.jpg" alt="" /></a>
            <div class="momo">
                <h1>Un Monopoly qui se termine en MOINS de 10 MINUTES, du jamais vu !</h1>
            </div>
            <p>Etiam tempor felis ac eros dictum quis consectetur dolor tristique. Aliquam scelerisque, odio vel luctus commodo, nisl nisl vehicula metus, ut lobortis eros sem blandit est. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut tempor, tortor at vulputate blandit, magna risus posuere turpis.</p>
            <a href="#" class="readmore">Read more</a>
        </article>
    </section>
    
    
    <div class="SNS  news m-4 ">
        <div id="fb-root ">
            <div class="fb-page " data-href="https://www.facebook.com/BonSensFrancais" data-tabs="timeline"
            data-width="350px" data-height="" data-small-header="false" data-adapt-container-width="true"
            data-hide-cover="false" data-show-facepile="true">
            <blockquote cite="https://www.facebook.com/BonSensFrancais" class="fb-xfbml-parse-ignore"><a
                href="https://www.facebook.com/BonSensFrancais%22%3ELe Bon Sens Français"></a></blockquote>
            </div>
        </div>
        <br>
        <table class="table-auto text-sm sticky top-0 m-4  overflow-hidden ">
  <thead>
    <tr class="bg-blue-300">
      <th class=" py-2 border border-blue-500">Derniers articles</th>
    </tr>
  </thead>
  <tbody>
    <tr class="bg-white">
      <td class="border  border-blue-500 text-center py-2">La Guerre a changer ! </td>
     
    </tr>
    <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
    </tr>
    <tr class="bg-white " >
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic </td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 15 des pires insultes, celles qui font très mal à ton amour propre </td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des dessins d’enfants les plus foirés de l’Histoire, enfin quand on comprend rien à l’Art </td>
    </tr>
  
  </tbody>
</table>
 <table class="table-auto text-sm sticky top-0 m-4  overflow-hidden ">
  <thead>
    <tr class="bg-blue-300">
      <th class=" py-2 border border-blue-500">Les plus vues</th>
      <th class=" py-2 border border-blue-500">Vues</th>
    </tr>
  </thead>
  <tbody>
    <tr class="bg-white">
      <td class="border  border-blue-500 text-center py-2">La Guerre a changer ! </td>
     <td class="border  border-blue-500 text-center py-2">9600</td>
    </tr>
    <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
      <td class="border  border-blue-500 text-center py-2 px-2">9600</td>
    </tr>
    <tr class="bg-white " >
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic</td>
      <td class="border  border-blue-500 text-center py-2  px-2">9600</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
      <td class="border  border-blue-500 text-center py-2  px-2">9600</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic </td>
      <td class="border  border-blue-500 text-center py-2  px-2">9600</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 15 des pires insultes, celles qui font très mal à ton amour propre </td>
      <td class="border  border-blue-500 text-center py-2  px-2">9600</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des dessins d’enfants les plus foirés de l’Histoire, enfin quand on comprend rien à l’Art </td>
      <td class="border  border-blue-500 text-center py-2  px-2">9600</td>
    </tr>
  
  </tbody>
  
</table>
 <table class="table-auto text-sm sticky top-0 m-4  overflow-hidden ">
  <thead>
    <tr class="bg-blue-300">
      <th class=" py-2 border border-blue-500">Les plus commentés</th>
      <th class=" py-2 border border-blue-500">Commentaires</th>
    </tr>
  </thead>
  <tbody>
    <tr class="bg-white">
      <td class="border  border-blue-500 text-center py-2">La Guerre a changer ! </td>
     <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
    <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
    <tr class="bg-white " >
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic</td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Un barbecue Dark vador , pour révéler le coté obscur des grillades  </td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des mots classes pour parler de cul, pour être salace mais chic </td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 15 des pires insultes, celles qui font très mal à ton amour propre </td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
    </tr>
      <tr class="bg-white ">
      <td class="border  border-blue-500 text-center py-2">Top 10 des dessins d’enfants les plus foirés de l’Histoire, enfin quand on comprend rien à l’Art </td>
       <td class="border  border-blue-500 text-center py-2  px-2">30</td>
       
    </tr>
    

  </tbody>
</table>

    </div>
    </main>