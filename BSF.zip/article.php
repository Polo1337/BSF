<?php require "boot.php";
 require "log.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link rel="stylesheet" href="css/footer.css">
     <link rel="stylesheet" href="css/article.css">
    <link rel="stylesheet" href="css/modal.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php' ?>
<?php include 'articlebody.php' ?>
<?php include 'footer.php' ?>

<script src="https://kit.fontawesome.com/22fcc891fe.js" crossorigin="anonymous"></script>
 
<script src="https://kit.fontawesome.com/22fcc891fe.js" crossorigin="anonymous"></script>
</body>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v6.0"></script>
</html>