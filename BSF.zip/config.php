<?php

return [
    "utilisateur"=>"dbu164958",
    "mdp"=>"PaPif5:e",
    "dsn"=>"mysql:host=db5000303931.hosting-data.io;dbname=dbs296967",
];