<?php
//configuration bdd
return [
    "utilisateur"=>"",
    "mdp"=>"",
    "dsn"=>"mysql:host=;dbname=",
];