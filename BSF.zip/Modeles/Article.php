<?php 
require_once "boot.php";
class Article
{
   
    public $id_article;
    public $nom_article;
    public $date_de_parution;
    public $photo_card;
    public $text_card;
    public $archive = 0;
    public $id_utilisateur;
    
}