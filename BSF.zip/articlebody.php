<div class='articletotal'>
    <div class='article'>
        <div class='articleimg'>
            <div><img src='img/post01.jpg'></div>
        </div>
        <div class='articletitle'>
            <p>Le titre qui va bien ici</p>
        </div>
        <div>
        <div class='articlecontent'>
            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                ex
                ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                fugiat
                nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                mollit
                anim id est laborum."</p>
        </div>
        <div class='articlefoot'>
            <ul>
                <li><a href=''>Tag</a></li>
                <li><a href=''>Tag</a></li>
                <li><a href=''>Tag</a></li>
            </ul>
            <p>Date et Heure de l'article</p>
        </div>
        </div>
        <div>
            <p>DERNIERS ARTICLES<p>
        </div>
        <div class='otherarticles'>
            <div class='otherarticle'>
                <div><img src='img/post01.jpg'>
                </div>
                <div>
                    <p>Titre de l'article</p>
                </div>
            </div>
            <div class='otherarticle'>
                <div><img src='img/post01.jpg'>
                </div>
                <div>
                    <p>Titre de l'article</p>
                </div>
            </div>
            <div class='otherarticle'>
                <div><img src='img/post01.jpg'>
                </div>
                <div>
                    <p>Titre de l'article</p>
                </div>
            </div>
        </div>
    </div>
    <div class="SNS">
        <div id="fb-root">
        <div class="fb-page" data-href="https://www.facebook.com/BonSensFrancais" data-tabs="timeline"
            data-width="350px" data-height="" data-small-header="false" data-adapt-container-width="true"
            data-hide-cover="false" data-show-facepile="true">
            <blockquote cite="https://www.facebook.com/BonSensFrancais" class="fb-xfbml-parse-ignore"><a
                    href="https://www.facebook.com/BonSensFrancais%22%3ELe Bon Sens Français"></a></blockquote>
                    </div>
        </div>
    </div>
</div>